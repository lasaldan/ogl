//
//  DGLCamera.cpp
//  wizards-court
//
//  Created by Daniel Fuller on 10/9/15.
//  Copyright (c) 2015 Daniel Fuller. All rights reserved.
//

#include "DGLCamera.h"

DGLCamera::DGLCamera() {
    position = Vertex(0,-1,3);
    rotationX = 0;
    rotationY = 0;
}